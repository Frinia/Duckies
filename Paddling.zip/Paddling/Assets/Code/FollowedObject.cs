﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class FollowedObject : MonoBehaviour
{
    
    // Use this for initialization
    void Start(){}

    public GameObject duckMom;
    public bool startfollowing = false;
    bool triggered = false;
    bool collides = false;

    // Update is called once per frame
    void Update()
    {
        // Debug.Log(gameObject);
        if (startfollowing == true)
        {
            // move towards duck if not colliding
            Vector2 momPosition = duckMom.transform.position;
            Vector2 momDirection = duckMom.transform.up;
            float momOffset = 0.4f;
            Vector2 targetPosition = momPosition + (momDirection * -1 * momOffset);

            transform.position = Vector2.MoveTowards(transform.position, targetPosition, 0.0900001f);

            Vector3 moveDirection = (Vector3)targetPosition - transform.position;

            if (moveDirection != Vector3.zero)
            {
                float angle = Mathf.Atan2(moveDirection.y, moveDirection.x) * Mathf.Rad2Deg;
                transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);
            }
            Vector3 rot = transform.eulerAngles;
            rot.z -= 90;
            transform.eulerAngles = rot;
        }
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (!triggered) {
            DuckmomMovement mom = collision.gameObject.GetComponent<DuckmomMovement>();

            if (null != mom)
            {
                duckMom = mom.AddDuck(this.gameObject);
                if (null != duckMom)
                    startfollowing = true;
                else {
                    // Do nothing
                }
            }
            triggered = true;
        }
    }
}