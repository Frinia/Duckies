﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class FollowedObject : MonoBehaviour
{
    
    // Use this for initialization
    void Start()
    {
        
    }
    
    public class Frame
    {
        public Vector3 position;
        public Quaternion rotation;
    }

    public List<Frame> formerPositions = new List<Frame>();
    public int frameDelay = 30;
    public float minimumDistance = 1;
    public GameObject duckMom;
    //Vector3 formerPosition = Vector3.zero;
    public bool startfollowing = false;
    bool triggered = false;

    // Update is called once per frame
    void Update()
    {
       // Debug.Log(gameObject);
        if (startfollowing == true) 
        transform.position = Vector3.MoveTowards(transform.position, duckMom.transform.position, 0.091f);
        /* if (formerPosition != transform.position)
         {
             formerPositions.Insert(0, new Frame { position = transform.position, rotation = transform.rotation });
             if (formerPositions.Count > frameDelay + 2)
                 formerPositions.RemoveAt(formerPositions.Count - 1);
         }
         formerPosition = transform.position;*/
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        
        // startfollowing = true;
        //Debug.Log("COLLISION");
        if (!triggered) {
            DuckmomMovement mom = collision.gameObject.GetComponent<DuckmomMovement>();

            if (null != mom)
            {
                Debug.Log("Passing GameObject to Mum!");
                duckMom = mom.AddDuck(this.gameObject);
                if (null != duckMom)
                    startfollowing = true;
                else
                    Debug.LogError("Add Duck Failed. Unable to follow");
            }
            triggered = true;
        }
    }
}