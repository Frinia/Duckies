﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Duck : MonoBehaviour
{
    public bool inArray = false; // How do we retrieve this in DuckmomMovement?

    public bool InArray()
    {
        return inArray;
    }
}
