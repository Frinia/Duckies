﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnDuck : MonoBehaviour
{
    public GameObject DuckmomPrefab;
    public GameObject ducklingPrefab;
    public Transform borderTop;
    public Transform borderBottom;
    public Transform borderLeft;
    public Transform borderRight;
    private float timer;
    public float interval;
    
    void Start()
    {
        timer = Time.time + interval;
        Spawn(DuckmomPrefab);
        
    }

    void Update()
    {
        if (Time.time >= timer)
        {
            Spawn(ducklingPrefab);
            timer = Time.time + interval;
        }

    }


    void Spawn(GameObject duckPrefab) 
    {
        int x = (int)Random.Range(borderLeft.position.x, borderRight.position.x);
        int y = (int)Random.Range(borderBottom.position.y, borderTop.position.y);
        Instantiate(duckPrefab, new Vector2(x, y), Quaternion.identity);
        
    }

}
