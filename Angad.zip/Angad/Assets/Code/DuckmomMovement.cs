﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DuckmomMovement : MonoBehaviour
{

    public float fTurnRate = 500.0f;
    public float fSpeed = 5.0f;

    public GameObject[] m_aDucks;
    public int m_iDuckCount = 0;

    void Start()
    {
        m_aDucks = new GameObject[32];
    }

    public GameObject AddDuck(GameObject duck)
    {
        if(null != duck)
        {
            // If Duck isn't in array
            //if (!duck.inArray) //?? How do we retrieve duck's custom variable?
            //if (!duck.GetComponent<Duck>.InArray()) { }
            Duck d = duck.GetComponent<Duck>();
            if (d.InArray() == false)
            {
                m_aDucks[m_iDuckCount] = duck;
            }
            ++m_iDuckCount;
            d.inArray = true;
            if (m_iDuckCount == 1)
                return this.gameObject;
            else
                return m_aDucks[m_iDuckCount - 2];
        }

        return null;
    }

    void Update()
    {
       

            if (Input.GetKey(KeyCode.LeftArrow))
                transform.Rotate(Vector3.forward * fTurnRate * Time.deltaTime);
            if (Input.GetKey(KeyCode.RightArrow))
                transform.Rotate(-Vector3.forward * fTurnRate * Time.deltaTime);

            transform.localPosition = transform.localPosition + transform.up * fSpeed * Time.deltaTime;
        }
    /*void OnTriggerEnter2D(Collider2D other)
    {
        Destroy(gameObject);
    }*/
    }
    
       
  

       



  
